# API Documentation for Sales Order API (salesorder-eapi)

## Overview - Purpose & Scope
The Sales Order API (salesorder-eapi) provides a robust interface for managing sales orders within the 3M ecosystem. The primary objective of this API is to facilitate the creation, retrieval, and updating of sales orders efficiently and securely. It aims to streamline order processing, enhance visibility into order status, and improve overall customer satisfaction by providing timely updates and management capabilities.

## Business Context
This API serves as a vital component of the sales order management process, enabling stakeholders to interact with sales order data in real-time. It integrates with various systems within the organization, ensuring that order data is consistent and accessible. The following diagram illustrates the business process flow:

```
[User Interface] --> [Sales Order API] --> [Order Management System]
```

## Scenarios, Use Cases & Audience
### Stakeholders
- **Product Managers**: Oversee the API's alignment with business goals.
- **Architects**: Ensure the API integrates seamlessly with existing systems.
- **QA Engineers**: Validate the API's functionality and performance.
- **Developers**: Implement the API in applications to manage sales orders.

### User Scenarios
1. **Retrieve Sales Order**: A user can fetch details of a specific sales order using its `mmmOrderId`.
2. **Update Sales Order**: Users can modify existing sales order details by sending PATCH requests with updated data.
3. **Check Service Status**: Users can ping the API to check its operational status.

## Service Scope/Constraints
This API is designed for use by authorized users within the 3M organization. Access is restricted based on authentication tokens, ensuring that only permitted users can perform operations. The API is applicable globally, but specific functionalities may vary based on regional regulations and customer requirements.

## Technical View
### API Endpoints
1. **Get Sales Order**
   - **Endpoint**: `/v1/salesorder/updateable/{mmmOrderId}`
   - **Method**: GET
   - **Parameters**:
     - `mmmOrderId` (path, required): The unique identifier for the sales order.
     - `status` (query, optional): Filter by order status.
     - `lineItemNumber` (query, optional): Filter by line item number.
     - `transactionId` (query, optional): API request transaction ID.
     - `Authorization` (header, required): OAuth token for authentication.

   - **Responses**:
     - `200 OK`: Returns the sales order details.
     - `400 Bad Request`: Indicates a malformed request.
     - `401 Unauthorized`: Indicates invalid authentication.
     - `404 Not Found`: Indicates the order ID does not exist.
     - `500 Internal Server Error`: Indicates a server-side error.

2. **Update Sales Order**
   - **Endpoint**: `/v1/salesorder/{mmmOrderId}`
   - **Method**: PATCH
   - **Parameters**:
     - `mmmOrderId` (path, required): The unique identifier for the sales order.
     - `Authorization` (header, required): OAuth token for authentication.
     - `Content-Type` (header, required): Must be set to `application/json`.
     - **Body**: JSON object containing updated sales order information.

   - **Responses**:
     - `200 OK`: Indicates successful update with order details.
     - `400 Bad Request`: Indicates a malformed request.
     - `500 Internal Server Error`: Indicates a server-side error.

3. **Ping Service**
   - **Endpoint**: `/ping`
   - **Method**: GET
   - **Responses**:
     - `200 OK`: Indicates the service is operational.
     - `500 Internal Server Error`: Indicates the service is down.

### Sequence Diagram
```plaintext
User --> API: GET /v1/salesorder/updateable/{mmmOrderId}
API --> Database: Fetch order details
Database --> API: Return order details
API --> User: 200 OK with order details
```

## Related APIs
- **Order Management API**: For broader order management functionalities.
- **Customer API**: To retrieve customer details associated with orders.

## Glossary & Definitions
- **mmmOrderId**: A unique identifier for a sales order in the 3M system.
- **Authorization**: A token required for authenticating API requests.
- **PATCH**: An HTTP method used to apply partial modifications to a resource.
- **GET**: An HTTP method used to retrieve data from a specified resource.
- **JWT**: JSON Web Token, a compact and self-contained way for securely transmitting information between parties.

This documentation provides a comprehensive overview of the Sales Order API, its functionalities, and how to interact with it effectively. For further information, please refer to the API specifications or reach out to the development team.