# API Documentation for product-spa-sapi

## Overview

### Purpose & Scope
The `product-spa-sapi` API is designed to facilitate the retrieval and management of Special Pricing Agreements (SPAs) and related contract information. This API serves as a critical integration point for applications that require access to pricing agreements, enabling efficient business operations and enhancing customer service.

### Business Objectives
- Provide a streamlined interface for accessing SPAs and contracts.
- Enhance the efficiency of pricing management across sales organizations.
- Support integration with other systems through standardized API calls.

---

## Business Context
The `product-spa-sapi` API plays a vital role in the pricing strategy of the organization. It allows stakeholders such as sales teams, customer service representatives, and partners to access SPAs and contract information seamlessly. 

### Business Process Flow
```plaintext
[User Request] --> [API Call] --> [Retrieve SPA/Contracts] --> [Response to User]
```

---

## Scenarios, Use Cases & Audience

### Stakeholders
- **Product Managers**: Monitor and manage SPA and contract offerings.
- **Architects**: Design and implement integrations with other systems.
- **QA Engineers**: Validate API functionality and performance.
- **Developers**: Integrate API into applications and services.

### Use Cases
1. **Retrieve Special Pricing Agreements**: Users can request SPAs based on specific criteria such as sales organization and customer details.
2. **List Contracts**: Users can obtain a list of contracts associated with specific products.

---

## Service Scope/Constraints
- The API is applicable to internal users and authorized partners.
- Access is restricted by authentication using JWT.
- The API is designed for HTTP requests and responses.

---

## Technical View

### API Endpoints

1. **Ping Endpoint**
   - **GET** `/ping`
   - **Description**: Checks the service status.
   - **Response**: Returns service health information.

2. **Special Pricing Agreements List**
   - **POST** `/v1/product/spaList`
   - **Description**: Retrieves Special Pricing Agreements.
   - **Request Body**: Requires a structured JSON object as per `post-request-schema`.

3. **Contracts List**
   - **POST** `/v1/product/contracts`
   - **Description**: Lists contracts associated with products.
   - **Request Body**: Requires a structured JSON object as per `post-contracts-request-schema`.

### Request and Response Examples

#### Example Request for SPA List
```json
{
  "locale": "en_US",
  "pageNumber": 1,
  "pageSize": 12,
  "sortBy": "NEW_SPA",
  "sortDirection": "ASC",
  "salesOrg": "1000",
  "customerSoldTos": [
    {
      "salesDistrict": "100039",
      "soldTo": "16117871"
    }
  ],
  "spaType": "ON_INVOICE",
  "currency": "USD",
  "configParams": {
    "decimalSymbol": ".",
    "dateFormat": "MM/dd/yyyy",
    "minimumFractionDigits": "2",
    "currentUserHasOrderEntryRole": "true",
    "useShiptoForOninvoice": "true",
    "enableOffInvoiceControlNumber": "false",
    "digitGroupSymbol": "%2C",
    "enablePRMLogic": "false",
    "enableLocalLanguageForAgreementAddresses": "false",
    "futurePricingNotificationPeriodForDeals": "0"
  },
  "requestFromPdp": true,
  "addressFormat": [
    "APARTMENT_NUMBER",
    "SPACE",
    "STREET_NAME",
    "SPACE",
    "STREET_NUMBER",
    "COMMA",
    "TOWN",
    "COMMA",
    "REGION",
    "SPACE",
    "POSTAL_CODE"
  ],
  "priceFormat": [
    "CURRENCY_SYMBOL",
    "PRICE"
  ]
}
```

#### Example Response for SPA List
```json
{
  "currentPage": 1,
  "numberOfPages": 1,
  "pageSize": 12,
  "totalResultCount": 1,
  "spaList": [
    {
      "businessInfo": {
        "accountNumber": "20280619",
        "address": {
          "apartmentNumber": "740",
          "streetName": "WATKINS RD",
          "town": "BATTLE CREEK",
          "region": "MICHIGAN",
          "postalCode": "49015-8695",
          "formattedAddress": "740 WATKINS RD BATTLE CREEK, MICHIGAN 49015-8695"
        },
        "name": "FREEDOM MOTORS",
        "formattedCustomerName": "FREEDOM MOTORS"
      },
      "spaInfo": {
        "formattedValidDateRange": "09/01/2021 - 12/31/2022",
        "salesDistrictId": "100039",
        "soldToId": "16117871",
        "spaNumber": "C001371558",
        "spaType": "CHANNEL_PARTNER",
        "validFrom": "09/01/2021",
        "validTo": "12/31/2022",
        "spaName": "FREEDOM MOTORS",
        "groupOrPricingPartnerId": "20280619",
        "newContract": false
      },
      "productRow": {
        "unitCode": "CA",
        "unitDescription": "Canister",
        "unitFactor": 1,
        "currency": "USD",
        "formattedPrice": "$ 5.09 / Canister",
        "price": 5.09,
        "mmmStockNumber": "7000044939",
        "salesDistrict": "100039",
        "soldTo": "16117871",
        "validFrom": "09/01/2021",
        "validTo": "12/31/2022"
      }
    }
  ]
}
```

### Error Responses
- **400 Bad Request**: Invalid request structure.
- **401 Unauthorized**: Missing or invalid authentication token.
- **500 Internal Server Error**: Unexpected server error.

---

## Related APIs
- **PAPI**: Product API for retrieving product details.
- **EAPI**: External API for third-party integrations.

---

## Glossary & Definitions
- **SPA**: Special Pricing Agreement.
- **JWT**: JSON Web Token, a compact, URL-safe means of representing claims to be transferred between two parties.
- **API**: Application Programming Interface, a set of rules that allows one software application to interact with another.

This documentation provides a comprehensive overview of the `product-spa-sapi` API, detailing its purpose, usage, and technical specifications. For further questions or support, please contact the API development team.