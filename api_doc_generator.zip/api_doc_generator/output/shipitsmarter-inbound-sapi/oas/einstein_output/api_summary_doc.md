# API Documentation for ShipItSmarter Inbound API

## Overview - Purpose & Scope

The ShipItSmarter Inbound API facilitates the integration of shipment data into the ShipItSmarter platform. This API is designed to streamline the process of sending shipment information, including tracking and handling details, ensuring that businesses can efficiently manage their shipping needs. The primary objectives for adopting this API include:

- **Efficiency**: Automate the inbound shipment processing to reduce manual entry and errors.
- **Real-time Data**: Provide real-time visibility into shipment statuses and details.
- **Integration**: Allow seamless integration with existing systems for better logistics management.

## Business Context

The ShipItSmarter Inbound API serves businesses that require an efficient way to handle shipments. This includes logistics companies, retailers, and any organization that relies on shipping products to customers. The API supports various shipment attributes, ensuring that all necessary information is captured for effective tracking and management.

### Business Process Flow

![Business Process Flow Diagram](#) *(Insert flow diagram here)*

1. **Initiate Shipment**: A shipment is created in the system.
2. **Send Shipment Data**: The shipment data is sent to the ShipItSmarter API.
3. **Process Shipment**: The API processes the shipment data and returns a response.
4. **Track Shipment**: Users can track the shipment status through the platform.

## Scenarios, Use Cases & Audience

### Stakeholders
- **Product Managers**: Oversee the integration and ensure it meets business needs.
- **Architects**: Design the system architecture to incorporate the API.
- **QA Engineers**: Test the API for reliability and performance.
- **Developers**: Implement the API into existing systems.

### Use Cases
1. **Sending Shipment Information**:
   - A logistics company sends all shipment details to the API to update the shipment status in real-time.
   
2. **Error Handling**:
   - If the shipment data is incorrect, the API will return an error response, allowing the developer to troubleshoot and resend the correct data.

3. **Service Status Check**:
   - Users can perform a health check on the API to ensure it is operational.

## Service Scope/Constraints

- **Availability**: The API is available for use by any customer group that has access to the ShipItSmarter platform.
- **Data Format**: The API accepts and returns data in XML and JSON formats.
- **Security**: Basic authentication is required for all API requests to ensure secure access.

## Technical View

### API Endpoints

#### 1. Shipment Inbound
- **Endpoint**: `/shipitsmarter/inbound/shipment`
- **Method**: `POST`
- **Description**: Submits shipment data to the ShipItSmarter platform.
- **Request Body**: Must be in XML format.
  
**Example Request**:
```xml
<?xml version="1.0"?>
<shipment_asn>
    <date_message>2023-12-08T09:15:59</date_message>
    <code_shipment>121269171</code_shipment>
    <service_level>EXPRESS</service_level>
    <SHIPFROM_HUB>C035</SHIPFROM_HUB>
    <date_pickup>2023-12-08</date_pickup>
    <time_pickup>07:52:00</time_pickup>
    <date_delivery_plan>2023-12-11</date_delivery_plan>
    <time_delivery_plan>17:00:00</time_delivery_plan>
    <carrier_name>TNT</carrier_name>
    <AWB>9223103006584307</AWB>
    <handling_unit>
        <Reference>SJUE1HEVRD</Reference>
        <collo_number>040018958017913767</collo_number>
        <package>CARTON</package>
        <weight>0.28</weight>
        <weight_uom>KG</weight_uom>
        <volume>0.036</volume>
        <volume_uom>M3</volume_uom>
        <width>40</width>
        <length>30</length>
        <height>30</height>
        <dim_uom>CM</dim_uom>
        <commercial_invoice>
            <item_number>70200749185</item_number>
            <quantity>0.25</quantity>
            <dg_uom>CV</dg_uom>
            <content>402468881200010</content>
            <CUSTOMER_PO_NUMBER>4510493136</CUSTOMER_PO_NUMBER>
            <lot_number>33T5FC</lot_number>
        </commercial_invoice>
    </handling_unit>
</shipment_asn>
```

**Responses**:
- **200 OK**: Successful submission of shipment data.
- **400 Bad Request**: Invalid request format or missing required fields.
- **404 Not Found**: Resource not found.
- **500 Internal Server Error**: An unexpected error occurred.

#### 2. Service Health Check
- **Endpoint**: `/ping`
- **Method**: `GET`
- **Description**: Checks the status of the API service.

**Example Response**:
```json
{
    "serviceHealth": {
        "serviceType": "http",
        "status": "UP"
    }
}
```

## Related APIs
- **Shipment Tracking API**: For tracking the status of shipments.
- **Order Management API**: For managing orders associated with shipments.

## Glossary & Definitions

- **API**: Application Programming Interface, a set of rules that allows different software entities to communicate.
- **XML**: Extensible Markup Language, a markup language used to encode documents in a format that is both human-readable and machine-readable.
- **JSON**: JavaScript Object Notation, a lightweight data interchange format that is easy for humans to read and write.
- **AWB**: Air Waybill, a document that accompanies goods shipped by an international courier.
- **Basic Authentication**: A simple authentication scheme built into the HTTP protocol.

This documentation provides a comprehensive overview of the ShipItSmarter Inbound API, its functionalities, and its integration capabilities. For further assistance, please refer to the API support team.