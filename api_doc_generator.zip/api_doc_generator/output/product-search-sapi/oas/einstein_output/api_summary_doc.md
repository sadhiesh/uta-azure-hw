# API Documentation for Product Search API (product-search-sapi)

## Overview

### Purpose & Scope
The Product Search API (product-search-sapi) enables users to search for product information through a standardized interface. This API is designed to provide product details, typeahead suggestions, and listing validations, facilitating efficient integration into various applications, including e-commerce platforms and inventory management systems.

### Business Objectives
- Enhance product discovery for users by providing quick and accurate search results.
- Streamline product information retrieval processes for developers and businesses.
- Support various client applications by exposing a robust and flexible API for product searches.

---

## Business Context

The Product Search API integrates with existing enterprise systems to provide real-time product information. This integration helps businesses manage their product catalogs effectively and ensures that customers have access to accurate product data.

### Business Process Flow
![Business Process Flow Diagram](URL_TO_DIAGRAM)

---

## Scenarios, Use Cases & Audience

### Scenarios / Use Cases
1. **Product Search**: Users can search for products using various identifiers (e.g., SKU, UPC).
2. **Typeahead Suggestions**: As users type, the API provides suggestions for relevant products.
3. **Product Details Retrieval**: Users can fetch detailed information about specific products.
4. **Product Listing Validation**: Businesses can check if products are actively listed in the catalog.

### Audience
- **Product Managers**: To understand product availability and features.
- **Architects**: To design systems that utilize the Product Search API.
- **QA Engineers**: To validate API responses and ensure compliance with business requirements.
- **Developers**: To integrate the API into applications and services.

---

## Service Scope / Constraints

The Product Search API is available for authorized users and is intended for use within specific customer groups and regions. Access may be restricted based on user roles and authentication requirements.

---

## Technical View

### Technical Description
The Product Search API provides several endpoints for different functionalities:

1. **Search Products**: `/v1/product/search`
   - Method: POST
   - Description: Searches for products based on specified criteria.
   - Request Body: Must include `size`, `start`, and `queryFields`.
   - Response: Returns product details.

2. **Typeahead Search**: `/v1/product/typeahead`
   - Method: POST
   - Description: Provides product suggestions as users type.
   - Request Body: Must include `q` (query string).
   - Response: Returns a list of suggested products.

3. **Product Details**: `/v1/product/details`
   - Method: POST
   - Description: Retrieves detailed information about specific products.
   - Request Body: Must include `mmm_id` (product identifier).
   - Response: Returns detailed product information.

4. **Product Listing Check**: `/v1/product/listing`
   - Method: POST
   - Description: Checks if a product is listed.
   - Request Body: Must include `transactionId`, `client`, `mmmId`, and `validationType`.
   - Response: Returns the listing status.

5. **Service Health Check**: `/ping`
   - Method: GET
   - Description: Checks the health status of the API.
   - Response: Returns the service status.

### Request and Response Examples

#### Search Products Example
**Request:**
```json
{
  "size": 10,
  "start": 0,
  "queryFields": [
    {"q": "7100085852", "field": "stockNo"},
    {"q": "00051138162078", "field": "upc"}
  ]
}
```

**Response:**
```json
{
  "transactionId": "abcd",
  "results": [
    {
      "mainImage": "https://example.com/image.jpg",
      "name": "Product Name",
      "uomData": [...]
    }
  ],
  "queryId": "f6e21f45-3fae-444e-9721-6cd57d9f6bf4",
  "totalHits": 1
}
```

#### Typeahead Search Example
**Request:**
```json
{
  "transactionId": "441b5146-f0ac-4dfa-ba01-d0d2d237882f",
  "q": "tape"
}
```

**Response:**
```json
{
  "catalogIdentifiers": [{"name": "Tape", "position": 0}],
  "products": [...]
}
```

---

## Related APIs

- **Product Availability API**: For checking product availability across different regions.
- **Inventory Management API**: For managing stock levels and inventory data.
- **Pricing API**: For retrieving product pricing information.

---

## Glossary & Definitions

- **API**: Application Programming Interface, a set of rules that allows different software entities to communicate.
- **SKU**: Stock Keeping Unit, a unique identifier for each distinct product and service that can be purchased.
- **UPCs**: Universal Product Codes, a type of barcode used for tracking trade items in stores.
- **JWT**: JSON Web Token, a compact, URL-safe means of representing claims to be transferred between two parties.

This documentation provides a comprehensive overview of the Product Search API, its functionalities, and its intended use cases. For further details, please refer to the API specifications or contact support.