uvicorn webserver.server:app --reload

# Visit: http://127.0.0.1:8000