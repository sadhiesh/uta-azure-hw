from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import os
import markdown
import pandas as pd
import configparser

app = FastAPI()
templates = Jinja2Templates(directory="webserver/templates")
app.mount("/static", StaticFiles(directory="webserver/static"), name="static")

def get_output_folder():
    config = configparser.ConfigParser()
    config.read("config/config.ini")
    return "./" + config.get("Settings", "output_folder")

DOC_ROOT = get_output_folder()
TARGET_OUTPUT_DIRS = {"einstein_output", "openai_output", "grok_output"}

def find_docs():
    doc_files = []
    for root, dirs, files in os.walk(DOC_ROOT):
        for target_dir in TARGET_OUTPUT_DIRS:
            if target_dir in dirs:
                output_path = os.path.join(root, target_dir)
                for file in os.listdir(output_path):
                    if file.endswith(".md"):
                        full_path = os.path.join(output_path, file)
                        relative = os.path.relpath(full_path, DOC_ROOT)
                        doc_files.append(relative.replace("\\", "/"))
    print(" Doc Files: " + str(doc_files))
    return doc_files

@app.get("/api-summary", response_class=HTMLResponse)
def api_summary(request: Request):
    docs = find_docs()
    return templates.TemplateResponse("api_summary.html", {"request": request, "files": docs})

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/docs/{path:path}", response_class=HTMLResponse)
def read_doc(request: Request, path: str):
    full_path = os.path.join(DOC_ROOT, path)
    if os.path.exists(full_path):
        with open(full_path, "r", encoding="utf-8") as f:
            md_content = f.read()
        html_content = markdown.markdown(md_content, extensions=["fenced_code", "tables"])
        return templates.TemplateResponse("doc_viewer.html", {"request": request, "html_content": html_content, "file_path": path})
    return HTMLResponse(content="File not found", status_code=404)

@app.get("/excel2", response_class=HTMLResponse)
def view_excel2(request: Request):
    excel_path = os.path.join(DOC_ROOT, "api_docs_summary.xlsx")
    if not os.path.exists(excel_path):
        return HTMLResponse("Excel file not found", status_code=404)
    print("Excel File Info: " + excel_path)
    try:
        df = pd.read_excel(excel_path)
        columns = df.columns.tolist()
        rows = df.values.tolist()
    except Exception as e:
        return HTMLResponse(f"Error reading Excel: {e}", status_code=500)

    #table_html = df.to_html(index=False, classes="table table-striped", border=0)
    #return templates.TemplateResponse("excel_viewer.html", {"request": request, "table_html": table_html})
    
    return templates.TemplateResponse("excel_viewer.html", {
        "request": request,
        "columns": columns,
        "rows": rows
    })


@app.get("/excel", response_class=HTMLResponse)
def view_excel(request: Request):
    excel_path = os.path.join(DOC_ROOT, "api_docs_summary.xlsx")
    if os.path.exists(excel_path):
        df = pd.read_excel(excel_path)
        records = df.to_dict(orient="records")
        columns = df.columns.tolist()
        return templates.TemplateResponse("excel_viewer.html", {
            "request": request,
            "records": records,
            "columns": columns
        })
    return HTMLResponse(content="Excel file not found", status_code=404)